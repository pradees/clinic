package com.capgemini.project.conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CommonCon {
	static Connection c;
	public  static Connection getCon() throws ClassNotFoundException {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl",
					"trg612","training612");
			System.out.println("connected");
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		return c;
		
	}
}
