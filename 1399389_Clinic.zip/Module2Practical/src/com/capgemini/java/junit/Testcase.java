package com.capgemini.java.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;

public class Testcase {

	@Test
	public void getId() {
		PatientBean b=new PatientBean();
		assertNotNull(b.getPatient_name());
	}

}
