package com.capgemini.tcc.service;

import java.sql.*;

import com.capgemini.project.conn.CommonCon;
import com.capgemini.tcc.bean.PatientBean;

public class PatientService implements IPatientService{
  Connection cn;
  PreparedStatement pst;
  static int id=1;
	@Override
	public void addPatientDetails(PatientBean PBobj) {
		// TODO Auto-generated method stub
		try {
			cn=CommonCon.getCon();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			pst = cn.prepareStatement("insert into Patient values(seq_1.NEXTVAL,?,?,?,?,?)");
			pst.setString(1,PBobj.getPatient_name());
			pst.setInt(2, PBobj.getAge());
			pst.setString(3, PBobj.getPhone());
			pst.setString(4, PBobj.getDescription());
			pst.setString(5, PBobj.getDate());
			pst.executeQuery();
			System.out.println("Patient information stored successfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	
}
