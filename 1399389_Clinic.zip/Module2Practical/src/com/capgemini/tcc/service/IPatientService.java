package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;

public interface IPatientService {
  void addPatientDetails(PatientBean patient);
  //void getPatientDetails(int patient_id);
}
