package com.capgemini.tcc.dao;

public class NoRecordFoundException extends Exception {
	public String toString() {
  	  
  	  return "There is no patient with this ID";
    }
}
