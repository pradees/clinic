package com.capgemini.tcc.dao;

public interface IPatientDAO {
       void getPatientDetails(int id);
       
}
