package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.capgemini.project.conn.CommonCon;

public class PatientDAO implements IPatientDAO{
      PreparedStatement pst;
      Connection cn;
      ResultSet rs;
      
	@Override
	public void getPatientDetails(int id) {
		// TODO Auto-generated method stub
		
		try {
			cn=CommonCon.getCon();
			Statement stmt = cn.createStatement();
			pst=cn.prepareStatement("select * from Patient where patient_id=?");
			
			pst.setInt(1, id);
			rs=pst.executeQuery();
			int count=0;
		    while(rs.next())
		    {
		    	count++;
		    	//int id1=rs.getInt(1);
		    	String name=rs.getString(2);
		    	int age=rs.getInt(3);
		    	String phone=rs.getString(4);
		    	String desc=rs.getString(5);
		    	String date=rs.getString(6);
		    	System.out.println("Name of the Patient :"+name);
		    	System.out.println("Age :"+age);
		    	System.out.println("Phone Number :"+phone);
		    	System.out.println("Description :"+desc);
		    	System.out.println("Consulting Date :"+date);
		    }
		    if(count==0)
		    	throw new NoRecordFoundException();
		
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
                     
}
