package com.capgemini.tcc.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.service.PatientService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		PatientBean PBobj=new PatientBean();
		//PatientDAO PDAOobj=new PatientDAO();
		System.out.println("Enter your Choice");
		System.out.println("\n1.Add Patient Information \n2.Search Patient by Id\n3.Exit");
        int ch=sc.nextInt();
		switch(ch)
		{
		 case 1:
		 {
			 //Inserting patient deatils in table
			 PatientService PSobj=new PatientService();
			 sc.nextLine();
			 System.out.println("Enter patient name");
			 String name=sc.nextLine();
			 PBobj.setPatient_name(name);
			 System.out.println("Enter patient age");
			 int age=sc.nextInt();
			 PBobj.setAge(age);
			 sc.nextLine();
			 System.out.println("Enter patient phone number");
			 String phone=sc.nextLine();
			 PBobj.setPhone(phone);
			 System.out.println("Enter Description");
			 String desc=sc.nextLine();
			 PBobj.setDescription(desc);
			 System.out.println("Consulting date");
			 LocalDate date=LocalDate.now();
			 String date1=LocaltoString(date);
			 PBobj.setDate(date1);
			 System.out.println(date1);
			 PSobj.addPatientDetails(PBobj);
			 break;
		 }
		 case 2:
		 {
			 //Retirval of patient details
			 PatientDAO PDAOobj=new PatientDAO();
			 System.out.println("Enter Patient_id to search");
			 int patientid=sc.nextInt();
			 PDAOobj.getPatientDetails(patientid);
			 
		 }
		 case 3:
		 {
			 //Exit the Appllication
			 System.out.println("Thank you");
			 return ;
		 }
		}
	}

	
	 //for Coverting Date to String Format to insert in database table
	private static String LocaltoString(LocalDate date) {
		// TODO Auto-generated method stub
		StringBuilder sb=new StringBuilder(date.toString());
		String mon=sb.substring(5,7);
		String month="";
		switch(mon)
		{
		case "01":
			month="JAN";
			break;
		case "02":
			month="FEB";
			break;
		case "03":
			month="MAR";
			break;
		case "04":
			month="APR";
			break;
		case "05":
			month="MAY";
			break;
		case "06":
			month="JUN";
			break;
		case "07":
			month="JUL";
			break;
		case "08":
			month="AUG";
			break;
		case "09":
			month="SEP";
			break;
		case "10":
			month="OCT";
			break;
		case "11":
			month="NOV";
			break;
		case "12":
			month="DEC";
			break;
			
		}
		String m1=sb.substring(8)+'-' +month+'-' +sb.substring(0,4);
		return m1;
	}

}
